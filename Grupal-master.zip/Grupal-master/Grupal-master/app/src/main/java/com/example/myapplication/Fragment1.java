package com.example.myapplication;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class Fragment1 extends Fragment implements View.OnClickListener {
    private ViewPager2 pager1, pager2;
    private com.google.android.material.button.MaterialButton boton, boton2;
    private String eleccion;
    String[]restaurantes={"papa john's", "wendy's","taco bell","running sushi","five guys"};
    String[]bares={"Arte y copas","La pera","Pera limonera","La sepia","La mejillonera"};

    View view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view=inflater.inflate(R.layout.fragment1, container, false);
        boton= view.findViewById(R.id.botonRestaurante);
        boton2 = view.findViewById(R.id.botonBar);
        boton.setOnClickListener(this);
        boton2.setOnClickListener(this);
        pager1 = view.findViewById(R.id.viewPager);
        MiAdaptador miAdaptador = new MiAdaptador();
        MiAdaptador2 miAdaptador2= new MiAdaptador2();
        pager1.setAdapter(miAdaptador);
        pager2= view.findViewById(R.id.viewPager2);
        pager2.setAdapter(miAdaptador2);
        return view;
    }

    @Override
    public void onClick(View v) {

    }
}
