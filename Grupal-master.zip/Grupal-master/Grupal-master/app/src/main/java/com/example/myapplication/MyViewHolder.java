package com.example.myapplication;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

class MyViewHolder extends RecyclerView.ViewHolder {


    private ImageView imageView;


    public MyViewHolder(@NonNull View itemView) {
        super(itemView);
        imageView = itemView.findViewById(R.id.imageView);
    }

    public void bind(int position) {
        switch (position) {
            case 0:
                imageView.setImageResource(R.drawable.fiveguys);
                break;
            case 1:
                imageView.setImageResource(R.drawable.runningsushi);
                break;
            case 2:
                imageView.setImageResource(R.drawable.logo_taco_bell_antes_0);
                break;
            case 3:
                imageView.setImageResource(R.drawable.papa);
                break;
            case 4:
                imageView.setImageResource(R.drawable.wendys);
                break;
        }
    }

    public ImageView getImageView() {
        return imageView;
    }
}

