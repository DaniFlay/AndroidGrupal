package com.example.myapplication;

import android.view.View;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

class MyViewHolder2 extends RecyclerView.ViewHolder {


    private ImageView imageView;


    public MyViewHolder2(@NonNull View itemView) {
        super(itemView);
        imageView = itemView.findViewById(R.id.imageView2);
    }

    public void bind(int position) {
        switch (position) {
            case 0:
                imageView.setImageResource(R.drawable.arteycopas);
                break;
            case 1:
                imageView.setImageResource(R.drawable.lapera);
                break;
            case 2:
                imageView.setImageResource(R.drawable.lasepia);
                break;
            case 3:
                imageView.setImageResource(R.drawable.mejillonera);
                break;
            case 4:
                imageView.setImageResource(R.drawable.peralimonera);
                break;
        }
    }

    public ImageView getImageView() {
        return imageView;
    }
}


